Planetary.js Site
=================

This is the source for the Planetary.js web site.

Building
--------

1. Install [Node.js](http://nodejs.org/)
2. Install the local dependencies with `npm install`
3. Run the development server with `npm start` (starts on port 9000) or compile the site to `www` with `npm run compile`
