Getting Help
============

[Stack Overflow](http://stackoverflow.com/) is a great place to get help when you're stuck on a particular issue. Tag your question with `planetary.js` when you post it.

If you think you've found a bug, hop over to [the Planetary.js issues page](https://github.com/BinaryMuse/planetary.js/issues) and file a bug (assuming the same bug hasn't already been reported).

If you have an idea for an improvement or other change, feel free to open a GitHub pull request.
